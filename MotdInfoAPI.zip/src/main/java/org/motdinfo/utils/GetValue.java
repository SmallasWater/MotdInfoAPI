package org.motdinfo.utils;

import java.util.LinkedHashMap;

/**
 * @author SmallasWater
 * Create on 2021/2/22 19:28
 * Package org.motdinfo.utils
 */
public class GetValue extends LinkedHashMap<String, String> {


    public GetValue(String name,String value){
        put(name, value);
    }


}
